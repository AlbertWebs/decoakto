/*
Template: Marblex - Marble & Tiles HTML Template
Author: Peacefulqode.com
Version: 1.0
Design and Developed by: Peacefulqode
*/


// ================ Home 1 ========================= //

var tpj = jQuery;
if (window.RS_MODULES === undefined) window.RS_MODULES = {};
if (RS_MODULES.modules === undefined) RS_MODULES.modules = {};
RS_MODULES.modules["revslider51"] = {
    once: RS_MODULES.modules["revslider51"] !== undefined ? RS_MODULES.modules["revslider51"].once : undefined, init: function () {
        window.revapi5 = window.revapi5 === undefined || window.revapi5 === null || window.revapi5.length === 0 ? document.getElementById("rev_slider_5_1") : window.revapi5;
        if (window.revapi5 === null || window.revapi5 === undefined || window.revapi5.length == 0) { window.revapi5initTry = window.revapi5initTry === undefined ? 0 : window.revapi5initTry + 1; if (window.revapi5initTry < 20) requestAnimationFrame(function () { RS_MODULES.modules["revslider51"].init() }); return; }
        window.revapi5 = jQuery(window.revapi5);
        if (window.revapi5.revolution == undefined) { revslider_showDoubleJqueryError("rev_slider_5_1"); return; }
        revapi5.revolutionInit({
            revapi: "revapi5",
            DPR: "dpr",
            sliderLayout: "fullwidth",
            visibilityLevels: "1240,1024,778,480",
            gridwidth: "1240,1024,778,480",
            gridheight: "1080,800,580,480",
            lazyType: "smart",
            perspective: 600,
            perspectiveType: "global",
            editorheight: "1080,800,580,480",
            responsiveLevels: "1240,1024,778,480",
            progressBar: { disableProgressBar: true },
            navigation: {
                onHoverStop: false
            },
            viewPort: {
                global: true,
                globalDist: "-200px",
                enable: false
            },
            fallbacks: {
                allowHTML5AutoPlayOnAndroid: true
            },
        });

    }
} // End of RevInitScript
if (window.RS_MODULES.checkMinimal !== undefined) { window.RS_MODULES.checkMinimal(); };



// ================ Home 2 ========================= //

var tpj = jQuery;
if (window.RS_MODULES === undefined) window.RS_MODULES = {};
if (RS_MODULES.modules === undefined) RS_MODULES.modules = {};
RS_MODULES.modules["revslider81"] = {
    once: RS_MODULES.modules["revslider81"] !== undefined ? RS_MODULES.modules["revslider81"].once : undefined, init: function () {
        window.revapi8 = window.revapi8 === undefined || window.revapi8 === null || window.revapi8.length === 0 ? document.getElementById("rev_slider_8_1") : window.revapi8;
        if (window.revapi8 === null || window.revapi8 === undefined || window.revapi8.length == 0) { window.revapi8initTry = window.revapi8initTry === undefined ? 0 : window.revapi8initTry + 1; if (window.revapi8initTry < 20) requestAnimationFrame(function () { RS_MODULES.modules["revslider81"].init() }); return; }
        window.revapi8 = jQuery(window.revapi8);
        if (window.revapi8.revolution == undefined) { revslider_showDoubleJqueryError("rev_slider_8_1"); return; }
        revapi8.revolutionInit({
            revapi: "revapi8",
            DPR: "dpr",
            sliderLayout: "fullwidth",
            visibilityLevels: "1240,1024,778,480",
            gridwidth: "1340,1024,778,480",
            gridheight: "1080,800,580,400",
            lazyType: "smart",
            perspective: 600,
            perspectiveType: "global",
            editorheight: "1080,800,580,400",
            responsiveLevels: "1240,1024,778,480",
            progressBar: { disableProgressBar: true },
            navigation: {
                wheelCallDelay: 1000,
                onHoverStop: false,
                bullets: {
                    enable: true,
                    tmp: "",
                    style: "hephaistos",
                    hide_onmobile: true,
                    hide_under: "1399px",
                    h_offset: 500,
                    v_offset: 200,
                    space: 10
                }
            },
            viewPort: {
                global: true,
                globalDist: "-200px",
                enable: false
            },
            fallbacks: {
                allowHTML5AutoPlayOnAndroid: true
            },
        });

    }
} // End of RevInitScript
if (window.RS_MODULES.checkMinimal !== undefined) { window.RS_MODULES.checkMinimal(); };


// ================ Home 3 ========================= //

var tpj = jQuery;
if (window.RS_MODULES === undefined) window.RS_MODULES = {};
if (RS_MODULES.modules === undefined) RS_MODULES.modules = {};
RS_MODULES.modules["revslider31"] = {
    once: RS_MODULES.modules["revslider31"] !== undefined ? RS_MODULES.modules["revslider31"].once : undefined, init: function () {
        window.revapi3 = window.revapi3 === undefined || window.revapi3 === null || window.revapi3.length === 0 ? document.getElementById("rev_slider_3_1") : window.revapi3;
        if (window.revapi3 === null || window.revapi3 === undefined || window.revapi3.length == 0) { window.revapi3initTry = window.revapi3initTry === undefined ? 0 : window.revapi3initTry + 1; if (window.revapi3initTry < 20) requestAnimationFrame(function () { RS_MODULES.modules["revslider31"].init() }); return; }
        window.revapi3 = jQuery(window.revapi3);
        if (window.revapi3.revolution == undefined) { revslider_showDoubleJqueryError("rev_slider_3_1"); return; }
        revapi3.revolutionInit({
            revapi: "revapi3",
            DPR: "dpr",
            sliderLayout: "fullwidth",
            visibilityLevels: "1240,1024,778,480",
            gridwidth: "1240,1024,778,480",
            gridheight: "1080,980,880,600",
            lazyType: "smart",
            perspective: 600,
            perspectiveType: "global",
            editorheight: "1080,980,880,600",
            responsiveLevels: "1240,1024,778,480",
            progressBar: { disableProgressBar: true },
            navigation: {
                wheelCallDelay: 1000,
                onHoverStop: false,
                arrows: {
                    enable: true,
                    style: "metis",
                    hide_onmobile: true,
                    hide_under: "1399px",
                    hide_onleave: true,
                    animSpeed: "500ms",
                    animDelay: "500ms",
                    left: {
                        h_offset: 30,
                        v_offset: 263
                    },
                    right: {
                        h_offset: 30,
                        v_offset: 263
                    }
                },
                bullets: {
                    enable: true,
                    tmp: "",
                    style: "hesperiden",
                    hide_over: "1399px",
                    v_offset: 15
                }
            },
            viewPort: {
                global: true,
                globalDist: "-200px",
                enable: false
            },
            fallbacks: {
                allowHTML5AutoPlayOnAndroid: true
            },
        });

    }
} // End of RevInitScript
if (window.RS_MODULES.checkMinimal !== undefined) { window.RS_MODULES.checkMinimal(); };


// ================ Home 4 ========================= //

var tpj = jQuery;
if (window.RS_MODULES === undefined) window.RS_MODULES = {};
if (RS_MODULES.modules === undefined) RS_MODULES.modules = {};
RS_MODULES.modules["revslider121"] = {
    once: RS_MODULES.modules["revslider121"] !== undefined ? RS_MODULES.modules["revslider121"].once : undefined, init: function () {
        window.revapi12 = window.revapi12 === undefined || window.revapi12 === null || window.revapi12.length === 0 ? document.getElementById("rev_slider_12_1") : window.revapi12;
        if (window.revapi12 === null || window.revapi12 === undefined || window.revapi12.length == 0) { window.revapi12initTry = window.revapi12initTry === undefined ? 0 : window.revapi12initTry + 1; if (window.revapi12initTry < 20) requestAnimationFrame(function () { RS_MODULES.modules["revslider121"].init() }); return; }
        window.revapi12 = jQuery(window.revapi12);
        if (window.revapi12.revolution == undefined) { revslider_showDoubleJqueryError("rev_slider_12_1"); return; }
        revapi12.revolutionInit({
            revapi: "revapi12",
            DPR: "dpr",
            sliderLayout: "fullwidth",
            visibilityLevels: "1240,1024,778,480",
            gridwidth: "1300,1024,778,480",
            gridheight: "1000,768,550,450",
            lazyType: "smart",
            perspective: 600,
            perspectiveType: "global",
            editorheight: "1000,768,550,450",
            responsiveLevels: "1240,1024,778,480",
            progressBar: { disableProgressBar: true },
            navigation: {
                wheelCallDelay: 1000,
                onHoverStop: false,
                arrows: {
                    enable: true,
                    tmp: "<div class=\"tp-title-wrap\">  	<div class=\"tp-arr-imgholder\"></div> </div>",
                    style: "zeus",
                    hide_onmobile: true,
                    hide_under: "1399px",
                    hide_onleave: true,
                    animSpeed: "100ms",
                    animDelay: "100ms",
                    left: {
                        h_offset: 30,
                        v_offset: 45
                    },
                    right: {
                        h_offset: 30,
                        v_offset: 45
                    }
                },
                bullets: {
                    enable: true,
                    tmp: "",
                    style: "hesperiden",
                    hide_over: "1399px",
                    v_offset: 10
                }
            },
            viewPort: {
                global: true,
                globalDist: "-200px",
                enable: false
            },
            fallbacks: {
                allowHTML5AutoPlayOnAndroid: true
            },
        });

    }
} // End of RevInitScript
if (window.RS_MODULES.checkMinimal !== undefined) { window.RS_MODULES.checkMinimal(); };


// ================ Home 5 ========================= //

var tpj = jQuery;
if (window.RS_MODULES === undefined) window.RS_MODULES = {};
if (RS_MODULES.modules === undefined) RS_MODULES.modules = {};
RS_MODULES.modules["revslider131"] = {
    once: RS_MODULES.modules["revslider131"] !== undefined ? RS_MODULES.modules["revslider131"].once : undefined, init: function () {
        window.revapi13 = window.revapi13 === undefined || window.revapi13 === null || window.revapi13.length === 0 ? document.getElementById("rev_slider_13_1") : window.revapi13;
        if (window.revapi13 === null || window.revapi13 === undefined || window.revapi13.length == 0) { window.revapi13initTry = window.revapi13initTry === undefined ? 0 : window.revapi13initTry + 1; if (window.revapi13initTry < 20) requestAnimationFrame(function () { RS_MODULES.modules["revslider131"].init() }); return; }
        window.revapi13 = jQuery(window.revapi13);
        if (window.revapi13.revolution == undefined) { revslider_showDoubleJqueryError("rev_slider_13_1"); return; }
        revapi13.revolutionInit({
            revapi: "revapi13",
            DPR: "dpr",
            sliderLayout: "fullwidth",
            visibilityLevels: "1240,1024,778,480",
            gridwidth: "1240,1024,778,480",
            gridheight: "980,768,550,400",
            lazyType: "smart",
            perspective: 600,
            perspectiveType: "global",
            editorheight: "980,768,550,400",
            responsiveLevels: "1240,1024,778,480",
            progressBar: { disableProgressBar: true },
            navigation: {
                wheelCallDelay: 1000,
                onHoverStop: false,
                arrows: {
                    enable: true,
                    style: "metis",
                    hide_onmobile: true,
                    hide_under: "1399px",
                    hide_onleave: true,
                    animSpeed: "500ms",
                    animDelay: "500ms",
                    left: {
                        h_align: "center",
                        v_align: "bottom",
                        h_offset: 300,
                        v_offset: 80
                    },
                    right: {
                        h_align: "center",
                        v_align: "bottom",
                        h_offset: 380,
                        v_offset: 80
                    }
                },
                bullets: {
                    enable: true,
                    tmp: "",
                    style: "hesperiden",
                    hide_over: "1399px"
                }
            },
            parallax: {
                levels: [5, 10, 15, 20, 25, 30, 35, 40, 45, 46, 47, 48, 49, 50, 51, 30],
                type: "mouse",
                origo: "slidercenter",
                speed: "1ms"
            },
            viewPort: {
                global: true,
                globalDist: "-200px",
                enable: false
            },
            fallbacks: {
                allowHTML5AutoPlayOnAndroid: true
            },
        });
    }
} // End of RevInitScript
if (window.RS_MODULES.checkMinimal !== undefined) { window.RS_MODULES.checkMinimal(); };


// ================ Home 6 ========================= //

var tpj = jQuery;
if (window.RS_MODULES === undefined) window.RS_MODULES = {};
if (RS_MODULES.modules === undefined) RS_MODULES.modules = {};
RS_MODULES.modules["revslider141"] = {
    once: RS_MODULES.modules["revslider141"] !== undefined ? RS_MODULES.modules["revslider141"].once : undefined, init: function () {
        window.revapi14 = window.revapi14 === undefined || window.revapi14 === null || window.revapi14.length === 0 ? document.getElementById("rev_slider_14_1") : window.revapi14;
        if (window.revapi14 === null || window.revapi14 === undefined || window.revapi14.length == 0) { window.revapi14initTry = window.revapi14initTry === undefined ? 0 : window.revapi14initTry + 1; if (window.revapi14initTry < 20) requestAnimationFrame(function () { RS_MODULES.modules["revslider141"].init() }); return; }
        window.revapi14 = jQuery(window.revapi14);
        if (window.revapi14.revolution == undefined) { revslider_showDoubleJqueryError("rev_slider_14_1"); return; }
        revapi14.revolutionInit({
            revapi: "revapi14",
            DPR: "dpr",
            sliderLayout: "fullwidth",
            visibilityLevels: "1240,1024,778,480",
            gridwidth: "1300,1024,778,480",
            gridheight: "1000,768,550,450",
            lazyType: "smart",
            perspective: 600,
            perspectiveType: "global",
            editorheight: "1000,768,550,450",
            responsiveLevels: "1240,1024,778,480",
            progressBar: { disableProgressBar: true },
            navigation: {
                wheelCallDelay: 1000,
                onHoverStop: false,
                arrows: {
                    enable: true,
                    tmp: "<div class=\"tp-title-wrap\">  	<div class=\"tp-arr-imgholder\"></div> </div>",
                    style: "zeus",
                    hide_onmobile: true,
                    hide_under: "1399px",
                    hide_onleave: true,
                    animSpeed: "100ms",
                    animDelay: "100ms",
                    left: {
                        h_offset: 30,
                        v_offset: 45
                    },
                    right: {
                        h_offset: 30,
                        v_offset: 45
                    }
                },
                bullets: {
                    enable: true,
                    tmp: "",
                    style: "hesperiden",
                    hide_over: "1399px",
                    v_offset: 10
                }
            },
            viewPort: {
                global: true,
                globalDist: "-200px",
                enable: false
            },
            fallbacks: {
                allowHTML5AutoPlayOnAndroid: true
            },
        });

    }
} // End of RevInitScript
if (window.RS_MODULES.checkMinimal !== undefined) { window.RS_MODULES.checkMinimal(); };